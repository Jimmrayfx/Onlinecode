1.0.1 (July 03, 2020)
Initial release - Sample source code for OTP Authentication demo.

1.1 (Nov 26, 2021)
Latest OS compatibility changes.
